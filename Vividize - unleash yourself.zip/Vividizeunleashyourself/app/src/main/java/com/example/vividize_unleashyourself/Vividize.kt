package com.example.vividize_unleashyourself

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class Vividize : Application() {
    override fun onCreate() {
        super.onCreate()

    }
}